#Project 1
<b>Due Date</b> - 9/1 <br />
<b>Comment</b> - Finish the implementation the 5 RA Operators that are partially implemented in Table.java. Store tuples in an ArrayList. Use a TreeMap for an index.

### Functions
| Function Name | Implemented By |
|----------------|---------------|
| Select  | Michael Bottone |
| Union  | Michael Bottone |
| Project  | Tiffany Chong |
| Minus  | Ashley Bennett |
| Equi-Join  | Jared McReynolds |
| Natural Join  | Jared McReynolds |

### Usage
- Compile - make compile
- Run - make run
- Test - make test
- Clean - make clean

### Assumptions
This is running on a machine with Java8 installed and configured.

### JavaDoc
Located in the doc folder. Open `index.html` in a web browser.
